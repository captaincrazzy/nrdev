module.exports = [

    {
        entry: {
            "info": "./app/views/info"
        },
        output: {
            filename: "./app/bundle/[name].js"
        }
    }

];
