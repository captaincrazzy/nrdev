module.exports = {

    el: '#info',

    data: {
        info: window.$info
    }

};

Vue.ready(module.exports);
