jQuery(function ($) {

    if ($('.pk-system-messages').children().length) {
        $('.js-login').addClass('uk-animation-shake').find('input:password').focus();
    }

});
